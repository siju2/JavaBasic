package homework0423;

public class BestGirl extends GoodGirl {
    @Override
    void show() {
        System.out.println("그녀는 자바를 무지하게 잘안다. ");
    }
}