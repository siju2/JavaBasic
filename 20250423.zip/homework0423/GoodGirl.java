package homework0423;

public class GoodGirl extends Girl {
	
    @Override
    
    void show() {
        System.out.println("그녀는 자바를 잘안다. ");
    }
}