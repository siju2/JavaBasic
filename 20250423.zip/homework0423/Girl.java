package homework0423;

public class Girl {
    void show() {
    	
    	
        System.out.println("그녀는 자바 초보자이다. ");
    }
}
