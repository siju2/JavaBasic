package homework0423;

public class GirlTest {
	
    public static void main(String[] args) {
    	
        Girl g1 = new Girl();
        
        Girl g2 = new GoodGirl(); 
        
        GoodGirl gg = new BestGirl();
   
        gg.show(); 
    }
}