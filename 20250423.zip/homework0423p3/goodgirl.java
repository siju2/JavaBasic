package homework0423p3;

public class goodgirl extends girl {

    public goodgirl(String name) {
    	
        super(name);
        
    }

    @Override
    
    void show() {
    	
        System.out.println(getName() + "는 자바를 잘 안다.");
        
    }
}