package homework0423p3;

public class girltest {
	
    public static void main(String[] args) {
    	
        girl[] girls = {
        		
            new girl("갑순이 "),
            
            new goodgirl("콩 쥐"),
            
            new bestgirl("황진이")
        };

        for (int i = 0; i < girls.length; i++) {
        	
            girls[i].show();
        }
    }
}
