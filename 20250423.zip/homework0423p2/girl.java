package homework0423p2;

public class girl {
	
    private String name;

    public girl(String name) {
        
    	this.name = name;
    }

    protected String getName() {
    
    	return name;
    }

    void show() {
        
    	System.out.println(name + "는 자바 초보자이다.");
    }
}