package homework0423p2;

public class bestgirl extends goodgirl {

    public bestgirl(String name) {
    	
        super(name);
        
    }

    @Override
    void show() {
        System.out.println(getName() + "는 자바를 무지하게 잘 안다.");
    }
}