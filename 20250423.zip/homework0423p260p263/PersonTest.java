package homework0423p260p263;

class Person {
	
    String name;
    
    int age;

    public Person(String name, int age) {
    	
        this.name = name;
        
        this.age = age;
    }

    void show() {
    	
       
    	System.out.println("사람[이름: " + name + ", 나이: " + age + "]");
    }
}

class Student extends Person {
	
    int studentId;

    public Student(String name, int age, int studentId) {
    	
        super(name, age);
        
        this.studentId = studentId;
    }

    void show() {
    	
        System.out.println("학생[이름: " + name + ", 나이: " + age + ", 학번: " + studentId + "]");
    }
}

class ForeignStudent extends Student {
	
    String nationality;

    public ForeignStudent(String name, int age, int studentId, String nationality) {
        
    	super(name, age, studentId);
        
    	this.nationality = nationality;
    }

    void show() {
    	
        System.out.println("외국학생[이름: " + name + ", 나이: " + age + ", 학번: " + studentId + ", 국적: " + nationality + "]");
    }
}

public class PersonTest {
	
    public static void main(String[] args) {
    	
        Person[] people = {
        		
            new Person("길동이", 22),
            new Student("황진이", 23, 100),
            new ForeignStudent("Amy", 30, 200, "U.S.A")
       
        };

        for (int i = 0; i < people.length; i++) {
        	
            people[i].show();
        
        }
    }
}
